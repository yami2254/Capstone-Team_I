package com.example.ex_login;

public class partner_list {
   private  String partner_id;
   private  String partner_name;

  public void setPartner_id(String partner_id){this.partner_id =partner_id;}
  public void setPartner_name(String partner_name){this.partner_name =partner_name;}

    public String getPartner_id() {
        return partner_id;
    }
    public String getPartner_name()
    {
        return partner_name;
    }
}
